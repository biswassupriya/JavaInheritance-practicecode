public class Main {
    public static void main(String[] args) {
        Parent p = new Parent();
        Parent pc = new Child();
        Child c = new Child();
        //Child cp = new Parent(); // Parent cannot be instantiated as a child
        p.back(); //In parent back method
        p.move(); //In Parent Move Method
        //p.lift(); // Lift belongs to child Class. Parent Cannot access it
        //pc.Lift(); //Child Method cannot be accessed by Parent
        pc.move(); //In parent move method  **
        pc.back(); //In parent back method
        c.lift(); //In child lift method
        c.move(); //In child move method
        c.back(); //In Parent back method

        //  Days d = Days.WEDNESDAY;
        // System.out.println(d.Numbers);

        System.out.println(Days.WEDNESDAY.Numbers);
        System.out.println(Days.WEDNESDAY.getValue());

        for (Days day : Days.values()) {
            if (day.Numbers == 3) {
                System.out.println(day);

            }
        }

    /*    Days wednesday = Days.WEDNESDAY;
        int a = wednesday.getValue();
        System.out.println(a);

        Days days = Days.valueOf(2); */

    }
}
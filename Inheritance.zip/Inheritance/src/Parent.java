import java.sql.SQLOutput;

public class Parent {

    public String move(){
        System.out.println("In Parent move method");
        return null;
    }

    public  void back(){
        System.out.println("In Parent back method");
    }
}

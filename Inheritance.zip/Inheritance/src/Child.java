public class Child extends Parent {

    public String move() {
        System.out.println("In child move method");
        return "";
    }

    public void lift() {
        System.out.println("In child lift method");
    }
}
